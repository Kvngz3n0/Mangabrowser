// Manga Scraper Collection
// Import all scrapers from this index

const BaseScraper = require('./base');
const MangaDexScraper = require('./scrapers/mangadex');
const MangaFoxScraper = require('./scrapers/mangafox');
const MangaKakalotScraper = require('./scrapers/mangakakalot');
const MangaNatoScraper = require('./scrapers/manganato');
const MangaHereScraper = require('./scrapers/mangahere');
const MangaParkScraper = require('./scrapers/mangapark');
const ReaperScansScraper = require('./scrapers/reaperscans');
const AsuraScansScraper = require('./scrapers/asurascans');
const WebtoonScraper = require('./scrapers/webtoon');
const MangaSeeScraper = require('./scrapers/mangasee');
const KingOfShoujoScraper = require('./scrapers/kingofshoujo');

module.exports = {
  BaseScraper,
  MangaDexScraper,
  MangaFoxScraper,
  MangaKakalotScraper,
  MangaNatoScraper,
  MangaHereScraper,
  MangaParkScraper,
  ReaperScansScraper,
  AsuraScansScraper,
  WebtoonScraper,
  MangaSeeScraper,
  KingOfShoujoScraper
};

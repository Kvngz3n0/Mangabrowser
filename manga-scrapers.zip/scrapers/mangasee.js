const BaseScraper = require('../base');

class MangaSeeScraper extends BaseScraper {
  constructor() {
    super('MangaSee', 'https://mangasee123.com', {
      timeout: 15000,
      retries: 3,
      headers: {
        'Referer': 'https://mangasee123.com/',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      }
    });
    this.baseUrl = 'https://mangasee123.com';
  }

  // Helper: Convert chapter string to MangaSee format
  chapterString(chapter) {
    const [integer, decimal] = chapter.toString().split('.');
    let result = integer.padStart(4, '0');
    if (decimal) {
      result += '-' + decimal;
    }
    return result;
  }

  // ─── 1. SEARCH ───
  async searchManga(query) {
    const html = await this.request(
      `${this.baseUrl}/search/?name=${encodeURIComponent(query)}`
    );
    const $ = this.loadHtml(html);
    const results = [];

    $('.top-15.ng-scope').each((_, el) => {
      const $el = $(el);
      const title = $el.find('.SeriesName.ng-binding').text().trim();
      const url = $el.find('a').attr('href');
      const cover = $el.find('.img-fluid').attr('src');
      const latest = $el.find('.ng-binding:contains("Chapter")').first().text().trim();
      const genres = $el.find('.ng-binding[ng-repeat="genre in Series.Genres"]')
                       .map((_, g) => $(g).text().trim()).get();

      if (title && url) {
        results.push({
          title,
          url: url.startsWith('http') ? url : `${this.baseUrl}${url}`,
          cover: cover?.startsWith('//') ? `https:${cover}` : cover,
          latestChapter: this.extractChapterNumber(latest),
          genres,
          type: 'manga'
        });
      }
    });
    return results;
  }

  // ─── 2. DETAILS ───
  async getMangaDetails(mangaUrl) {
    const html = await this.request(mangaUrl);
    const $ = this.loadHtml(html);

    // MangaSee stores data in a script variable
    const scriptMatch = html.match(/vm\.IndexName\s*=\s*["'](.*?)["'];/);
    const indexName = scriptMatch ? scriptMatch[1] : '';

    const title = $('.SeriesName').text().trim();
    const cover = $('.img-fluid').attr('src');
    const description = $('.top-5.Content').text().trim();
    const author = $('.list-group-item:contains("Author")').text().replace('Author(s):', '').trim() || '';
    const status = $('.list-group-item:contains("Status")').text().replace('Status:', '').trim() || 'Unknown';
    const genres = $('.list-group-item:contains("Genre") a')
                  .map((_, a) => $(a).text().trim()).get();
    const altTitles = $('.list-group-item:contains("Alternate Name")').text()
                     .replace('Alternate Name(s):', '').trim();
    const year = $('.list-group-item:contains("Year")').text().replace('Year of Release:', '').trim();

    // Parse chapters from script
    const chaptersMatch = html.match(/vm\.Chapters\s*=\s*(\[.*?\]);/s);
    const chapters = [];

    if (chaptersMatch) {
      try {
        const chapterData = JSON.parse(chaptersMatch[1]);
        chapterData.forEach(ch => {
          const chNum = parseFloat(ch.Chapter) / 100000;
          const chString = this.chapterString(chNum);
          const chUrl = `${this.baseUrl}/read-online/${indexName}-chapter-${chString}.html`;

          chapters.push({
            number: chNum,
            title: ch.ChapterName || `Chapter ${chNum}`,
            url: chUrl,
            date: ch.Date,
            type: ch.Type
          });
        });
      } catch (e) {
        console.error('Failed to parse chapters:', e);
      }
    }

    return {
      title,
      cover: cover?.startsWith('//') ? `https:${cover}` : cover,
      description,
      author,
      status,
      genres,
      altTitles: altTitles ? altTitles.split(',').map(s => s.trim()).filter(Boolean) : [],
      year: year ? parseInt(year) : null,
      type: 'manga',
      latestChapter: chapters[0]?.number || 0,
      chapters: chapters.reverse(),
      url: mangaUrl,
      indexName
    };
  }

  // ─── 3. CHAPTER PAGES ───
  async getChapterPages(chapterUrl) {
    const html = await this.request(chapterUrl);
    const pages = [];

    // MangaSee stores page data in script variables
    const curPathMatch = html.match(/vm\.CurPathName\s*=\s*["'](.*?)["'];/);
    const curChapterMatch = html.match(/vm\.CurChapter\s*=\s*(\{.*?\});/s);

    if (curPathMatch && curChapterMatch) {
      try {
        const curPathName = curPathMatch[1];
        const curChapter = JSON.parse(curChapterMatch[1]);
        const directory = curChapter.Directory ? `/${curChapter.Directory}` : '';
        const pageCount = parseInt(curChapter.Page);

        for (let i = 1; i <= pageCount; i++) {
          const pageString = i.toString().padStart(3, '0');
          pages.push(`https://${curPathName}/manga/${curChapter.IndexName}${directory}/${curChapter.Chapter}-${pageString}.png`);
        }
      } catch (e) {
        console.error('Failed to parse page data:', e);
      }
    }

    return pages;
  }

  // ─── 4. LATEST ───
  async getLatestManga(page = 1) {
    const html = await this.request(`${this.baseUrl}/`);
    const $ = this.loadHtml(html);
    const results = [];

    $('.latest-updates .top-15').each((_, el) => {
      const $el = $(el);
      const title = $el.find('.SeriesName').text().trim();
      const url = $el.find('a').attr('href');
      const cover = $el.find('.img-fluid').attr('src');
      const latest = $el.find('.ng-binding').first().text().trim();

      if (title && url) {
        results.push({ 
          title, 
          url: url.startsWith('http') ? url : `${this.baseUrl}${url}`, 
          cover: cover?.startsWith('//') ? `https:${cover}` : cover,
          latestChapter: this.extractChapterNumber(latest)
        });
      }
    });
    return results;
  }
}

module.exports = MangaSeeScraper;

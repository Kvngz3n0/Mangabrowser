const BaseScraper = require('../base');

class MangaNatoScraper extends BaseScraper {
  constructor() {
    super('MangaNato', 'https://chapmanganato.to', {
      timeout: 15000,
      retries: 3,
      headers: {
        'Referer': 'https://chapmanganato.to/'
      }
    });
    this.baseUrl = 'https://chapmanganato.to';
    this.searchUrl = 'https://manganato.com';
  }

  // ─── 1. SEARCH ───
  async searchManga(query) {
    const html = await this.request(
      `${this.searchUrl}/search/story/${encodeURIComponent(query).replace(/%20/g, '_')}`
    );
    const $ = this.loadHtml(html);
    const results = [];

    $('.search-story-item').each((_, el) => {
      const $el = $(el);
      const title = $el.find('.item-title').text().trim();
      const url = $el.find('.item-title').attr('href');
      const cover = $el.find('img').attr('src');
      const author = $el.find('.item-author').text().trim();
      const updated = $el.find('.item-time').text().trim();
      const views = $el.find('.item-time').eq(1).text().trim();
      const description = $el.find('.item-summary').text().trim();

      if (title && url) {
        results.push({
          title,
          url,
          cover,
          author,
          updated,
          views,
          description,
          type: 'manga'
        });
      }
    });
    return results;
  }

  // ─── 2. DETAILS ───
  async getMangaDetails(mangaUrl) {
    const html = await this.request(mangaUrl);
    const $ = this.loadHtml(html);

    const title = $('.story-info-right h1').text().trim();
    const cover = $('.info-image img').attr('src');
    const description = $('#panel-story-info-description').text()
                       .replace('Description :', '').trim();
    const author = $('.variations-tableInfo tr:contains("Author") td a')
                  .first().text().trim() || '';
    const status = $('.variations-tableInfo tr:contains("Status") td')
                  .text().trim() || 'Unknown';
    const genres = $('.variations-tableInfo tr:contains("Genres") td a')
                  .map((_, a) => $(a).text().trim()).get();
    const rating = $('.manga-info-text li:contains("Rating")').text().match(/(\d+\.?\d*)/)?.[0];
    const altTitles = $('.story-info-right-extent p:contains("Alternative")').text()
                     .replace('Alternative :', '').trim();
    const updated = $('.story-info-right-extent p:contains("Updated")').text()
                   .replace('Updated :', '').trim();
    const views = $('.story-info-right-extent p:contains("View")').text()
                 .replace('View :', '').trim();

    const chapters = [];
    $('.row-content-chapter li').each((_, el) => {
      const $el = $(el);
      const chTitle = $el.find('.chapter-name').text().trim();
      const chUrl = $el.find('.chapter-name').attr('href');
      const chDate = $el.find('.chapter-time').text().trim();
      const chViews = $el.find('.chapter-view').text().trim();
      const chNum = this.extractChapterNumber(chTitle);

      if (chUrl) {
        chapters.push({ 
          number: chNum, 
          title: chTitle, 
          url: chUrl, 
          date: chDate,
          views: chViews
        });
      }
    });

    return {
      title,
      cover,
      description,
      author,
      status,
      genres,
      altTitles: altTitles ? altTitles.split(';').map(s => s.trim()).filter(Boolean) : [],
      rating: rating ? parseFloat(rating) : null,
      views,
      updated,
      type: 'manga',
      latestChapter: chapters[0]?.number || 0,
      chapters: chapters.reverse(),
      url: mangaUrl
    };
  }

  // ─── 3. CHAPTER PAGES ───
  async getChapterPages(chapterUrl) {
    const html = await this.request(chapterUrl);
    const $ = this.loadHtml(html);
    const pages = [];

    $('.container-chapter-reader img').each((_, el) => {
      const src = $(el).attr('src') || $(el).attr('data-src');
      if (src) pages.push(src);
    });

    return pages;
  }

  // ─── 4. LATEST ───
  async getLatestManga(page = 1) {
    const html = await this.request(
      `${this.searchUrl}/genre-all/${page}?type=newest`
    );
    const $ = this.loadHtml(html);
    const results = [];

    $('.content-genres-item').each((_, el) => {
      const $el = $(el);
      const title = $el.find('.genres-item-name').text().trim();
      const url = $el.find('.genres-item-name').attr('href');
      const cover = $el.find('img').attr('src');
      const author = $el.find('.genres-item-author').text().trim();
      const updated = $el.find('.genres-item-time').text().trim();
      const rating = $el.find('.genres-item-rate').text().trim();

      if (title && url) {
        results.push({ 
          title, 
          url, 
          cover,
          author,
          updated,
          rating: rating ? parseFloat(rating) : null
        });
      }
    });
    return results;
  }
}

module.exports = MangaNatoScraper;

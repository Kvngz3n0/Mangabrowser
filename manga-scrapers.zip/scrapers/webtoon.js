const BaseScraper = require('../base');

class WebtoonScraper extends BaseScraper {
  constructor() {
    super('Webtoon', 'https://www.webtoons.com', {
      timeout: 15000,
      retries: 3,
      headers: {
        'Referer': 'https://www.webtoons.com/',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });
    this.baseUrl = 'https://www.webtoons.com';
    this.apiBase = 'https://global.apis.naver.com';
  }

  // ─── 1. SEARCH ───
  async searchManga(query) {
    const html = await this.request(
      `${this.baseUrl}/en/search?keyword=${encodeURIComponent(query)}`
    );
    const $ = this.loadHtml(html);
    const results = [];

    $('.card_lst li').each((_, el) => {
      const $el = $(el);
      const title = $el.find('.subj').text().trim();
      const url = $el.find('a').attr('href');
      const cover = $el.find('img').attr('src');
      const author = $el.find('.author').text().trim();
      const genre = $el.find('.genre').text().trim();

      if (title && url) {
        results.push({
          title,
          url: url.startsWith('http') ? url : `${this.baseUrl}${url}`,
          cover,
          author,
          genre,
          type: 'webtoon'
        });
      }
    });
    return results;
  }

  // ─── 2. DETAILS ───
  async getMangaDetails(mangaUrl) {
    const html = await this.request(mangaUrl);
    const $ = this.loadHtml(html);

    const title = $('.subj').first().text().trim();
    const cover = $('.detail_header .pic_area img').attr('src')
               || $('.detail_bg').css('background-image')?.replace(/url\(["']?|["']?\)/g, '');
    const description = $('.summary').text().trim();
    const author = $('.author_area .author').first().text().trim() || '';
    const genre = $('.genre').first().text().trim();
    const rating = $('.grade_area .grade_num').text().trim();
    const subscribers = $('.grade_area .sub_cnt').text().trim();
    const updateDays = $('.day_info').text().trim();

    const chapters = [];
    $('#_listUl li').each((_, el) => {
      const $el = $(el);
      const chTitle = $el.find('.subj span').text().trim();
      const chUrl = $el.find('a').attr('href');
      const chDate = $el.find('.date').text().trim();
      const chNum = this.extractChapterNumber(chTitle);
      const isFree = !$el.hasClass('_paidEpisode');

      if (chUrl) {
        chapters.push({ 
          number: chNum, 
          title: chTitle, 
          url: chUrl.startsWith('http') ? chUrl : `${this.baseUrl}${chUrl}`, 
          date: chDate,
          isFree
        });
      }
    });

    return {
      title,
      cover,
      description,
      author,
      genre,
      rating: rating ? parseFloat(rating) : null,
      subscribers,
      updateDays,
      type: 'webtoon',
      latestChapter: chapters[0]?.number || 0,
      chapters: chapters.reverse(),
      url: mangaUrl
    };
  }

  // ─── 3. CHAPTER PAGES ───
  async getChapterPages(chapterUrl) {
    const html = await this.request(chapterUrl);
    const $ = this.loadHtml(html);
    const pages = [];

    // Webtoon uses a specific image container
    $('#_imageList img').each((_, el) => {
      const src = $(el).attr('data-url') || $(el).attr('src');
      if (src) pages.push(src);
    });

    return pages;
  }

  // ─── 4. LATEST ───
  async getLatestManga(page = 1) {
    const html = await this.request(
      `${this.baseUrl}/en/dailySchedule`
    );
    const $ = this.loadHtml(html);
    const results = [];

    $('.daily_lst li').each((_, el) => {
      const $el = $(el);
      const title = $el.find('.subj').text().trim();
      const url = $el.find('a').attr('href');
      const cover = $el.find('img').attr('src');
      const author = $el.find('.author').text().trim();

      if (title && url) {
        results.push({ 
          title, 
          url: url.startsWith('http') ? url : `${this.baseUrl}${url}`, 
          cover,
          author
        });
      }
    });
    return results;
  }
}

module.exports = WebtoonScraper;

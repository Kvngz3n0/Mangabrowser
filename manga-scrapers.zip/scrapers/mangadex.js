const BaseScraper = require('../base');

class MangaDexScraper extends BaseScraper {
  constructor() {
    super('MangaDex', 'https://api.mangadex.org', {
      timeout: 20000,
      retries: 3,
      headers: {
        'Content-Type': 'application/json'
      }
    });
    this.apiBase = 'https://api.mangadex.org';
    this.webBase = 'https://mangadex.org';
  }

  // ─── 1. SEARCH ───
  async searchManga(query, limit = 20) {
    const data = await this.request(
      `${this.apiBase}/manga?title=${encodeURIComponent(query)}&limit=${limit}&includes[]=cover_art&includes[]=author&includes[]=artist&contentRating[]=safe&contentRating[]=suggestive&contentRating[]=erotica&order[relevance]=desc`
    );

    return data.data.map(manga => {
      const attrs = manga.attributes;
      const title = attrs.title.en || Object.values(attrs.title)[0] || 'Unknown';
      const coverRel = manga.relationships?.find(r => r.type === 'cover_art');
      const cover = coverRel ? 
        `${this.webBase}/covers/${manga.id}/${coverRel.attributes?.fileName}` : null;
      const author = manga.relationships?.find(r => r.type === 'author')?.attributes?.name || '';

      return {
        id: manga.id,
        title,
        url: `${this.webBase}/title/${manga.id}`,
        cover,
        description: attrs.description?.en || '',
        status: attrs.status || 'Unknown',
        year: attrs.year,
        tags: attrs.tags?.map(t => t.attributes?.name?.en).filter(Boolean) || [],
        contentRating: attrs.contentRating,
        latestChapter: attrs.lastChapter || 0,
        type: 'manga'
      };
    });
  }

  // ─── 2. DETAILS ───
  async getMangaDetails(mangaId) {
    // Accept either full URL or just ID
    const id = mangaId.includes('/') ? mangaId.split('/').pop() : mangaId;

    const [mangaData, feedData, statsData] = await Promise.all([
      this.request(`${this.apiBase}/manga/${id}?includes[]=cover_art&includes[]=author&includes[]=artist`),
      this.request(`${this.apiBase}/manga/${id}/feed?limit=500&translatedLanguage[]=en&order[chapter]=desc&includes[]=scanlation_group`),
      this.request(`${this.apiBase}/statistics/manga/${id}`).catch(() => ({ statistics: {} }))
    ]);

    const attrs = mangaData.data.attributes;
    const title = attrs.title.en || Object.values(attrs.title)[0] || 'Unknown';
    const coverRel = mangaData.data.relationships?.find(r => r.type === 'cover_art');
    const cover = coverRel ? 
      `${this.webBase}/covers/${id}/${coverRel.attributes?.fileName}` : null;
    const author = mangaData.data.relationships?.find(r => r.type === 'author')?.attributes?.name || '';
    const artist = mangaData.data.relationships?.find(r => r.type === 'artist')?.attributes?.name || '';

    const chapters = feedData.data.map(ch => ({
      id: ch.id,
      number: parseFloat(ch.attributes.chapter) || 0,
      title: ch.attributes.title || `Chapter ${ch.attributes.chapter}`,
      url: `${this.webBase}/chapter/${ch.id}`,
      pages: ch.attributes.pages,
      translatedLanguage: ch.attributes.translatedLanguage,
      publishAt: ch.attributes.publishAt,
      scanlationGroup: ch.relationships?.find(r => r.type === 'scanlation_group')?.attributes?.name || 'Unknown',
      readableAt: ch.attributes.readableAt
    }));

    const stats = statsData.statistics?.[id] || {};

    return {
      id,
      title,
      cover,
      description: attrs.description?.en || Object.values(attrs.description || {})[0] || '',
      author: author || artist,
      artist,
      status: attrs.status || 'Unknown',
      year: attrs.year,
      contentRating: attrs.contentRating,
      tags: attrs.tags?.map(t => t.attributes?.name?.en).filter(Boolean) || [],
      originalLanguage: attrs.originalLanguage,
      lastVolume: attrs.lastVolume,
      lastChapter: attrs.lastChapter,
      type: 'manga',
      latestChapter: chapters[0]?.number || 0,
      chapters,
      url: `${this.webBase}/title/${id}`,
      rating: stats.rating?.average ? (stats.rating.average / 2).toFixed(1) : null,
      follows: stats.follows || 0,
      comments: stats.comments?.repliesCount || 0
    };
  }

  // ─── 3. CHAPTER PAGES ───
  async getChapterPages(chapterId) {
    const id = chapterId.includes('/') ? chapterId.split('/').pop() : chapterId;

    const [chapterData, atHomeData] = await Promise.all([
      this.request(`${this.apiBase}/chapter/${id}?includes[]=manga`),
      this.request(`${this.apiBase}/at-home/server/${id}`)
    ]);

    const baseUrl = atHomeData.baseUrl;
    const hash = atHomeData.chapter.hash;
    const data = atHomeData.chapter.data;
    const dataSaver = atHomeData.chapter.dataSaver;

    return {
      chapter: chapterData.data,
      pages: data.map(filename => `${baseUrl}/data/${hash}/${filename}`),
      dataSaver: dataSaver.map(filename => `${baseUrl}/data-saver/${hash}/${filename}`),
      hash
    };
  }

  // ─── 4. LATEST ───
  async getLatestManga(page = 1, limit = 20) {
    const offset = (page - 1) * limit;
    const data = await this.request(
      `${this.apiBase}/manga?limit=${limit}&offset=${offset}&includes[]=cover_art&contentRating[]=safe&contentRating[]=suggestive&order[latestUploadedChapter]=desc`
    );

    return data.data.map(manga => {
      const attrs = manga.attributes;
      const title = attrs.title.en || Object.values(attrs.title)[0] || 'Unknown';
      const coverRel = manga.relationships?.find(r => r.type === 'cover_art');
      const cover = coverRel ? 
        `${this.webBase}/covers/${manga.id}/${coverRel.attributes?.fileName}` : null;

      return {
        id: manga.id,
        title,
        url: `${this.webBase}/title/${manga.id}`,
        cover,
        latestChapter: attrs.lastChapter || 0,
        updatedAt: attrs.updatedAt,
        type: 'manga'
      };
    });
  }

  // ─── 5. POPULAR ───
  async getPopularManga(page = 1, limit = 20) {
    const offset = (page - 1) * limit;
    const data = await this.request(
      `${this.apiBase}/manga?limit=${limit}&offset=${offset}&includes[]=cover_art&contentRating[]=safe&contentRating[]=suggestive&order[followedCount]=desc`
    );

    return data.data.map(manga => {
      const attrs = manga.attributes;
      const title = attrs.title.en || Object.values(attrs.title)[0] || 'Unknown';
      const coverRel = manga.relationships?.find(r => r.type === 'cover_art');
      const cover = coverRel ? 
        `${this.webBase}/covers/${manga.id}/${coverRel.attributes?.fileName}` : null;

      return {
        id: manga.id,
        title,
        url: `${this.webBase}/title/${manga.id}`,
        cover,
        type: 'manga'
      };
    });
  }
}

module.exports = MangaDexScraper;

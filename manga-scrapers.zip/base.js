const axios = require('axios');
const cheerio = require('cheerio');

class BaseScraper {
  constructor(name, baseUrl, options = {}) {
    this.name = name;
    this.baseUrl = baseUrl;
    this.timeout = options.timeout || 15000;
    this.retries = options.retries || 3;
    this.headers = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.0.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.0.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.5',
      'Accept-Encoding': 'gzip, deflate, br',
      'DNT': '1',
      'Connection': 'keep-alive',
      'Upgrade-Insecure-Requests': '1',
      ...options.headers
    };
  }

  async request(url, options = {}) {
    let lastError;
    for (let i = 0; i < this.retries; i++) {
      try {
        const response = await axios.get(url, {
          timeout: this.timeout,
          headers: { ...this.headers, ...options.headers },
          ...options
        });
        return response.data;
      } catch (error) {
        lastError = error;
        if (i < this.retries - 1) {
          await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        }
      }
    }
    throw lastError;
  }

  loadHtml(html) {
    return cheerio.load(html);
  }

  extractChapterNumber(title) {
    if (!title) return 0;
    const match = title.match(/(?:Chapter|Ch\.?|Ep\.?|Episode)?\s*(\d+(?:\.\d+)?)/i);
    return match ? parseFloat(match[1]) : 0;
  }

  async searchManga(query) {
    throw new Error('searchManga must be implemented');
  }

  async getMangaDetails(mangaUrl) {
    throw new Error('getMangaDetails must be implemented');
  }

  async getChapterPages(chapterUrl) {
    throw new Error('getChapterPages must be implemented');
  }

  async getLatestManga(page = 1) {
    throw new Error('getLatestManga must be implemented');
  }
}

module.exports = BaseScraper;

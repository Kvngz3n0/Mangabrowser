const express = require('express');
const cors = require('cors');
const compression = require('compression');
const helmet = require('helmet');
const path = require('path');
const Database = require('./database/db');
const ScraperEngine = require('./scraper/engine');
const { registerAllScrapers } = require('./scraper/sources');

const app = express();
const db = new Database();
const engine = new ScraperEngine();
registerAllScrapers(engine);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(compression());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/search', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) return res.status(400).json({ error: 'Query required' });
    const results = await engine.searchAll(q);
    for (const manga of results) await engine.saveToDatabase(manga);
    res.json({ success: true, count: results.length, results });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/manga/:id', async (req, res) => {
  try {
    const manga = await db.get('SELECT * FROM manga WHERE id = ?', [req.params.id]);
    if (!manga) return res.status(404).json({ error: 'Not found' });
    const sources = await db.all('SELECT * FROM sources WHERE manga_id = ?', [req.params.id]);
    const chapters = await db.all('SELECT * FROM chapters WHERE manga_id = ? ORDER BY chapter_number DESC', [req.params.id]);
    res.json({ ...manga, sources, chapters });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/manga/:id/details', async (req, res) => {
  try {
    const manga = await db.get('SELECT * FROM manga WHERE id = ?', [req.params.id]);
    if (!manga) return res.status(404).json({ error: 'Not found' });
    const sources = await db.all('SELECT * FROM sources WHERE manga_id = ?', [req.params.id]);
    const details = await engine.getMangaDetails(manga.title, sources);
    res.json(details);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/chapter/:source/:chapterId', async (req, res) => {
  try {
    const { source, chapterId } = req.params;
    const scraper = engine.scrapers.get(source);
    if (!scraper) return res.status(404).json({ error: 'Source not found' });
    const pages = await scraper.getChapterPages(chapterId);
    res.json({ success: true, pages });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/latest', async (req, res) => {
  try {
    const results = await engine.getLatestFromAll();
    res.json({ success: true, results });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/library', async (req, res) => {
  try {
    const { type, status, page = 1, limit = 20 } = req.query;
    let sql = 'SELECT * FROM manga WHERE 1=1';
    const params = [];
    if (type) { sql += ' AND type = ?'; params.push(type); }
    if (status) { sql += ' AND status = ?'; params.push(status); }
    sql += ' ORDER BY updated_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), (parseInt(page) - 1) * parseInt(limit));
    const manga = await db.all(sql, params);
    res.json({ success: true, manga });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/stats', async (req, res) => {
  try {
    const totalManga = await db.get('SELECT COUNT(*) as count FROM manga');
    const totalChapters = await db.get('SELECT COUNT(*) as count FROM chapters');
    const totalSources = await db.get('SELECT COUNT(DISTINCT source_name) as count FROM sources');
    const byType = await db.all('SELECT type, COUNT(*) as count FROM manga GROUP BY type');
    res.json({ totalManga: totalManga.count, totalChapters: totalChapters.count, totalSources: totalSources.count, byType });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', sources: Array.from(engine.scrapers.keys()) });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Imperious Manga Aggregator on port ${PORT}`);
  console.log(`Sources: ${engine.scrapers.size}`);
});

module.exports = app;

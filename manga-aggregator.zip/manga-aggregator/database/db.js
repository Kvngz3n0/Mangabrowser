const sqlite3 = require('sqlite3').verbose');
const path = require('path');
const DB_PATH = path.join(__dirname, 'manga.db');

class Database {
  constructor() {
    this.db = new sqlite3.Database(DB_PATH);
  }
  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) reject(err);
        else resolve({ id: this.lastID, changes: this.changes });
      });
    });
  }
  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  }
  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  }
  close() {
    this.db.close();
  }
}
module.exports = Database;
